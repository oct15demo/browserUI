/* ------------------------------------------------------------------
 * This source code, its documentation and all appendant files
 * are protected by copyright law. All rights reserved.
 *
 * Copyright, 2003 - 2008
 * University of Konstanz, Germany
 * and KNIME GmbH, Konstanz, Germany
 *
 * You may not modify, publish, transmit, transfer or sell, reproduce,
 * create derivative works from, distribute, perform, display, or in
 * any way exploit any of the content, in whole or in part, except as
 * otherwise expressly permitted in writing by the copyright owner or
 * as specified in the license file distributed with this product.
 *
 * If you have any questions please contact the copyright holder:
 * website: www.knime.org
 * email: contact@knime.org
 * ---------------------------------------------------------------------
 * 
 * History
 *   Mar 13, 2008 (ohl): created
 */
package mypackage;

import java.io.File;
import java.io.IOException;

import org.knime.core.data.DataTableSpec;
import org.knime.core.node.BufferedDataTable;
import org.knime.core.node.CanceledExecutionException;
import org.knime.core.node.ExecutionContext;
import org.knime.core.node.ExecutionMonitor;
import org.knime.core.node.InvalidSettingsException;
import org.knime.core.node.NodeModel;
import org.knime.core.node.NodeSettingsRO;
import org.knime.core.node.NodeSettingsWO;
import org.knime.core.node.defaultnodesettings.SettingsModelBoolean;
import org.knime.core.node.defaultnodesettings.SettingsModelInteger;
import org.knime.core.node.defaultnodesettings.SettingsModelString;

/**
 * 
 * @author ohl, University of Konstanz
 */
public class TestNodeModel extends NodeModel {

    /** user selection in the drop down box. */
    static final String[] SELECTION = new String[]{"FIRST", "SECOND", "THIRD"};

    /**
     * creates a new model holding the user selected value.
     * 
     * @return a new settings model for the user selection
     */
    static SettingsModelString createSettingsModelSelection() {
        return new SettingsModelString("SELECTION", "");
    }

    /**
     * creates a new model holding another user parameter.
     * 
     * @return a new settings model for the user parameter
     */
    static SettingsModelInteger createSettingsModelValue() {
        SettingsModelInteger result = new SettingsModelInteger("VALUE", 0);
        /*
         * because the "enable" settings model is initialized false (see method
         * below) and this model's component depends on its value, we must
         * disable this model:
         */
        result.setEnabled(false);
        return result;
    }

    /**
     * only needed to store the status of the parameter edit field.
     * 
     * @return a new settings model indication user changed parameters
     */
    static SettingsModelBoolean createSettingsModelEnabled() {
        // the initial value false
        return new SettingsModelBoolean("ENABLE", false);
    }

    private final SettingsModelString m_selection =
            createSettingsModelSelection();

    private final SettingsModelInteger m_value = createSettingsModelValue();

    private final SettingsModelBoolean m_enabled = createSettingsModelEnabled();

    /**
     * Le createur.
     */
    TestNodeModel() {
        super(1, 1);

        /*
         * ensure correct enable/value status
         */
        m_value.setIntValue(m_selection.getStringValue().hashCode());
        m_value.setEnabled(m_enabled.getBooleanValue());

    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected DataTableSpec[] configure(final DataTableSpec[] inSpecs)
            throws InvalidSettingsException {
        // TODO Auto-generated method stub
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected BufferedDataTable[] execute(final BufferedDataTable[] inData,
            final ExecutionContext exec) throws Exception {
        // TODO Auto-generated method stub
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void loadInternals(final File nodeInternDir,
            final ExecutionMonitor exec) throws IOException,
            CanceledExecutionException {
        // TODO Auto-generated method stub

    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void loadValidatedSettingsFrom(final NodeSettingsRO settings)
            throws InvalidSettingsException {
        m_enabled.loadSettingsFrom(settings);
        m_selection.loadSettingsFrom(settings);
        m_value.loadSettingsFrom(settings);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void reset() {
        // TODO Auto-generated method stub

    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void saveInternals(final File nodeInternDir,
            final ExecutionMonitor exec) throws IOException,
            CanceledExecutionException {
        // TODO Auto-generated method stub

    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void saveSettingsTo(final NodeSettingsWO settings) {
        m_enabled.saveSettingsTo(settings);
        m_selection.saveSettingsTo(settings);
        m_value.saveSettingsTo(settings);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    protected void validateSettings(final NodeSettingsRO settings)
            throws InvalidSettingsException {
        m_enabled.validateSettings(settings);
        m_selection.validateSettings(settings);
        m_value.validateSettings(settings);
    }

}

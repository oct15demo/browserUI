/* ------------------------------------------------------------------
 * This source code, its documentation and all appendant files
 * are protected by copyright law. All rights reserved.
 *
 * Copyright, 2003 - 2008
 * University of Konstanz, Germany
 * and KNIME GmbH, Konstanz, Germany
 *
 * You may not modify, publish, transmit, transfer or sell, reproduce,
 * create derivative works from, distribute, perform, display, or in
 * any way exploit any of the content, in whole or in part, except as
 * otherwise expressly permitted in writing by the copyright owner or
 * as specified in the license file distributed with this product.
 *
 * If you have any questions please contact the copyright holder:
 * website: www.knime.org
 * email: contact@knime.org
 * ---------------------------------------------------------------------
 * 
 * History
 *   Mar 13, 2008 (ohl): created
 */
package mypackage;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import org.knime.core.node.defaultnodesettings.DefaultNodeSettingsPane;
import org.knime.core.node.defaultnodesettings.DialogComponentBoolean;
import org.knime.core.node.defaultnodesettings.DialogComponentNumberEdit;
import org.knime.core.node.defaultnodesettings.DialogComponentStringSelection;
import org.knime.core.node.defaultnodesettings.SettingsModelBoolean;
import org.knime.core.node.defaultnodesettings.SettingsModelInteger;
import org.knime.core.node.defaultnodesettings.SettingsModelString;

/**
 * 
 * @author ohl, University of Konstanz
 */
public class TestDialogPane extends DefaultNodeSettingsPane {

    /**
     * Constructs the dialog pane.
     */
    public TestDialogPane() {

        final SettingsModelString selection =
                TestNodeModel.createSettingsModelSelection();
        final SettingsModelBoolean enabled =
                TestNodeModel.createSettingsModelEnabled();
        final SettingsModelInteger parameter =
                TestNodeModel.createSettingsModelValue();

        /*
         * install listener to maintain enable status of parameter field
         */
        enabled.addChangeListener(new ChangeListener() {
            public void stateChanged(final ChangeEvent e) {
                // if enabled is true, the parameter field should be enabled
                parameter.setEnabled(enabled.getBooleanValue());
            }
        });
        /*
         * listener to pre-set a value in the parameter, depending on the
         * selection.
         */
        selection.addChangeListener(new ChangeListener() {
            public void stateChanged(final ChangeEvent e) {
                int param = selection.getStringValue().hashCode();
                // we override any previously entered value!
                parameter.setIntValue(param);
            }
        });

        /*
         * add components using the above settings models
         */
        createNewGroup("Your choice");
        addDialogComponent(new DialogComponentStringSelection(selection,
                "Select one:", TestNodeModel.SELECTION));

        createNewGroup("Parameter");
        setHorizontalPlacement(true);
        addDialogComponent(new DialogComponentBoolean(enabled, 
                "edit manually"));
        addDialogComponent(new DialogComponentNumberEdit(parameter, "", 15));
    }
}
